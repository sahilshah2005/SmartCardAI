
- Built an AI-powered demand forecasting platform.
- Developed inventory optimization recommendations.
- Created analytics dashboard for retail operations.
