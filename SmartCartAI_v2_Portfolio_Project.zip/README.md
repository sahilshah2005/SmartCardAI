# SmartCart AI
Enterprise-style retail demand forecasting and inventory optimization platform.

## Modules
- Demand Forecasting
- Inventory Optimization
- Warehouse Analytics
- Executive Dashboard
- Risk Alerts

## Tech Stack
Python, Pandas, Scikit-Learn, Streamlit, SQLite

## Structure
See /docs for architecture and report.
